﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        int width = 20;
        int height = 20;
        List<List<char>> grid = new List<List<char>>();
        List<List<ConsoleColor>> colorGrid = new List<List<ConsoleColor>>();

        for (int i = 0; i < height; i++)
        {
            grid.Add(new List<char>());
            colorGrid.Add(new List<ConsoleColor>());
            for (int j = 0; j < width; j++)
            {
                grid[i].Add(' ');
                colorGrid[i].Add(ConsoleColor.White);
            }
        }

        int posX = 0, posY = 0;
        ConsoleColor currentColor = ConsoleColor.White;
        ConsoleKey key;

        while (true)
        {
            Console.Clear();

            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    if (i == posY && j == posX)
                    {
                        Console.ForegroundColor = currentColor;
                        Console.Write('#');
                    }
                    else
                    {
                        Console.ForegroundColor = colorGrid[i][j];
                        Console.Write(grid[i][j]);
                    }
                }
                Console.WriteLine();
            }

            key = Console.ReadKey(true).Key;

            if (key == ConsoleKey.UpArrow && posY > 0)
                posY--;
            else if (key == ConsoleKey.DownArrow && posY < height - 1)
                posY++;
            else if (key == ConsoleKey.LeftArrow && posX > 0)
                posX--;
            else if (key == ConsoleKey.RightArrow && posX < width - 1)
                posX++;
            else if (key == ConsoleKey.Spacebar)
            {
                grid[posY][posX] = '#';
                colorGrid[posY][posX] = currentColor;
            }
            else if (key == ConsoleKey.D1)
                currentColor = ConsoleColor.Red;
            else if (key == ConsoleKey.D2)
                currentColor = ConsoleColor.Green;
            else if (key == ConsoleKey.D3)
                currentColor = ConsoleColor.Blue;
            else if (key == ConsoleKey.D4)
                currentColor = ConsoleColor.Yellow;
            else if (key == ConsoleKey.D5)
                currentColor = ConsoleColor.Cyan;
            else if (key == ConsoleKey.D6)
                currentColor = ConsoleColor.Magenta;
            else if (key == ConsoleKey.D7)
                currentColor = ConsoleColor.Gray;
            else if (key == ConsoleKey.D8)
                currentColor = ConsoleColor.White;
            else
                break;
        }

        Console.ResetColor();
    }
}
helyi menü tartozik hozzá

